
-- Tom & Jerry learning games: Supabase schema + least-privilege policies
-- Run in Supabase SQL Editor after creating the project.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  role text not null default 'student' check (role in ('teacher','student')),
  created_at timestamptz not null default now()
);

create table if not exists public.games (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  subject text not null default 'Tiếng Việt',
  grade smallint not null default 1,
  description text not null default '',
  game_type text not null default 'quiz' check (game_type in ('quiz','canva','html')),
  content jsonb not null default '{}'::jsonb,
  published boolean not null default true,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.game_attempts (
  id uuid primary key default gen_random_uuid(),
  game_id uuid not null references public.games(id) on delete cascade,
  student_name text not null,
  class_name text not null default '',
  score integer not null default 0 check (score >= 0),
  total integer not null default 0 check (total >= 0),
  duration_seconds integer not null default 0 check (duration_seconds >= 0),
  played_at timestamptz not null default now()
);

create or replace function public.is_teacher()
returns boolean
language sql
security definer
set search_path = public
stable
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'teacher'
  );
$$;

alter table public.profiles enable row level security;
alter table public.games enable row level security;
alter table public.game_attempts enable row level security;

-- Profile users can read their own profile; only teacher may inspect profiles.
create policy "profile self read" on public.profiles
for select to authenticated using (id = auth.uid() or public.is_teacher());

-- Students/anonymous visitors can only read published games.
create policy "public read published games" on public.games
for select to anon, authenticated using (published = true);

-- Teacher-only game authoring, editing, deleting.
create policy "teacher insert games" on public.games
for insert to authenticated with check (public.is_teacher());
create policy "teacher update games" on public.games
for update to authenticated using (public.is_teacher()) with check (public.is_teacher());
create policy "teacher delete games" on public.games
for delete to authenticated using (public.is_teacher());

-- Students may submit attempts, but cannot read the class-wide results.
create policy "submit game attempt" on public.game_attempts
for insert to anon, authenticated with check (true);
create policy "teacher read attempts" on public.game_attempts
for select to authenticated using (public.is_teacher());
create policy "teacher manage attempts" on public.game_attempts
for all to authenticated using (public.is_teacher()) with check (public.is_teacher());

-- IMPORTANT: create teacher account in Supabase Auth first, then replace UUID below.
-- Never expose service_role key in browser code.
-- insert into public.profiles (id, display_name, role)
-- values ('PASTE_AUTH_USER_UUID_HERE', 'Giáo viên', 'teacher')
-- on conflict (id) do update set role='teacher', display_name='Giáo viên';
