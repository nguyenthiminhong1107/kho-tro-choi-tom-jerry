// Example only. Replace with your Supabase project values.
// This anon/publishable key is intended for browser use only with RLS enabled.
export const SUPABASE_URL = 'https://YOUR_PROJECT.supabase.co';
export const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY';
// NEVER put service_role/secret keys in this file.
