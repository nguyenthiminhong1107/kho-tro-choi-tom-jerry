// Cau hinh Firebase Web App cua Kho tro choi Tom & Jerry - Khoi 1 TQD.
// apiKey trong Firebase Web config la khoa cong khai; khong dat service-account/private key o day.
window.FIREBASE_CONFIG = {
  apiKey: "AIzaSyAGRk5tPUZJQ9VzLSOG_4xlPzP1J-h24jU",
  authDomain: "kho-tro-choi-tom-jerry-4c2c7.firebaseapp.com",
  projectId: "kho-tro-choi-tom-jerry-4c2c7",
  storageBucket: "kho-tro-choi-tom-jerry-4c2c7.firebasestorage.app",
  messagingSenderId: "115472574918",
  appId: "1:115472574918:web:a3430ea044065fa7fe6ac7",
  measurementId: "G-DK3QH96D72"
};
window.TEACHER_EMAIL = "nguyenthiminhong1107@gmail.com";
