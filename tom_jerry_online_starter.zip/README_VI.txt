# Tom & Jerry – Bộ khởi tạo triển khai trực tuyến

## Có trong gói
- `index.html`: giao diện hiện tại đã tối ưu cho điện thoại.
- `supabase_schema.sql`: cấu trúc dữ liệu và chính sách phân quyền cơ sở dữ liệu.

## Kiến trúc đề xuất
- Hosting: Netlify (website tĩnh + tên miền riêng).
- Backend: Supabase Auth + Postgres + Row Level Security.
- Một tài khoản giáo viên duy nhất; học sinh truy cập kho trò chơi công khai.
- Học sinh chỉ đọc trò chơi đã xuất bản và gửi lượt chơi; không đọc bảng kết quả.
- Giáo viên có quyền tạo/sửa/xóa trò chơi và xem thống kê.

## Các bước triển khai
1. Đăng ký/mua tên miền tại nhà đăng ký tên miền; chưa cần đổi DNS.
2. Tạo tài khoản Netlify và tạo site mới bằng cách kéo thả thư mục chứa `index.html` (hoặc kết nối Git).
3. Netlify cấp địa chỉ tạm `*.netlify.app`; kiểm tra website trước.
4. Tạo dự án Supabase. Mở SQL Editor, chạy toàn bộ `supabase_schema.sql`.
5. Trong Supabase Authentication, tạo một người dùng bằng email/mật khẩu cho giáo viên.
6. Sao chép UUID của người dùng đó từ trang Users, thay `PASTE_AUTH_USER_UUID_HERE` trong lệnh INSERT cuối file SQL rồi chạy lệnh đó.
7. Trong Netlify, vào Domain management → Add a domain → Add a domain you already own; nhập tên miền.
8. Làm theo đúng bản ghi DNS mà Netlify hiển thị cho tên miền của bạn. Không tự đoán hoặc thay bản ghi. Chờ DNS xác minh và HTTPS được cấp.
9. Cấu hình URL website trong Supabase Auth → URL Configuration (Site URL và Redirect URLs).

## Lưu ý kỹ thuật quan trọng
Gói này là bộ khởi tạo triển khai và phân quyền dữ liệu, chưa phải bản tích hợp hoàn chỉnh Supabase trong giao diện HTML. Cần nối các thao tác đăng nhập giáo viên, tải danh sách game, lưu game và gửi lượt chơi với Supabase SDK trước khi dùng dữ liệu trực tuyến thật. Hiện `index.html` vẫn có một số dữ liệu lưu trên trình duyệt (localStorage). Không được đưa Supabase `service_role` key vào HTML/JavaScript phía trình duyệt.

## Phân quyền
- Giáo viên: xác thực bằng email/mật khẩu; `profiles.role='teacher'`.
- Học sinh: không cần tài khoản quản trị; chỉ xem game đã xuất bản và gửi lượt chơi.
- Không cấp quyền SELECT cho học sinh trên `game_attempts`.
- Chỉ dùng `anon` key công khai ở client sau khi RLS đã bật; bí mật `service_role` chỉ dùng ở máy chủ an toàn.
