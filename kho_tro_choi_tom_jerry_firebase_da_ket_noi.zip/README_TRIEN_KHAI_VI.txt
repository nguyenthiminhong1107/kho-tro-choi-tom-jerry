KHO TRO CHOI TOM & JERRY - KHOI 1 TQD
Bo ma nguon: GitHub Pages + Firebase

CAC FILE CAN TAI LEN GITHUB (de cung cap o thu muc goc repository)
1. index.html
2. firebase-config.js
3. firestore.rules (chi de tham khao/sao chep vao Firebase Rules, khong tu dong ap dung)

THONG TIN DU AN DA CAU HINH
- Firebase Project ID: kho-tro-choi-tom-jerry-4c2c7
- Web app nickname: Tom Jerry Khoi 1 TQD
- Tai khoan giao vien duoc phep: nguyenthiminhong1107@gmail.com

BUOC A - BAT DANG NHAP GIAO VIEN
1. Mo Firebase Console > chon du an kho-tro-choi-tom-jerry.
2. Menu Build > Authentication > Get started.
3. Tab Sign-in method (hoac Sign-in providers) > Email/Password > Enable > Save.
4. Mo tab Users > Add user.
5. Nhap email nguyenthiminhong1107@gmail.com va tao mat khau rieng. Luu mat khau an toan, khong gui cho ChatGPT.
6. Dung email va mat khau nay de dang nhap giao vien. Khong chia se mat khau.

BUOC B - TAO FIRESTORE DATABASE
1. Firebase Console > Build > Firestore Database > Create database.
2. Chon Start in production mode.
3. Chon region gan nguoi dung (vi du asia-southeast1 neu hien thi va phu hop). Luu y: region da chon kho thay doi.
4. Tao database.
5. Mo tab Rules, thay noi dung bang toan bo file firestore.rules trong bo ma nguon, sau do bam Publish.
6. Rules nay cho phep moi nguoi doc games co published=true; moi nguoi co the gui mot ban ghi attempts theo schema gioi han; chi tai khoan da dang nhap bang email giao vien moi doc attempts va quan tri games.

BUOC C - TAI FILE LEN GITHUB (SAU KHI DA CAU HINH FIREBASE)
1. Mo repository: https://github.com/nguyenthiminhong1107/kho-tro-choi-tom-jerry
2. Chon Add file > Upload files.
3. Tai len index.html va firebase-config.js (co the tai README va firestore.rules de luu tai lieu).
4. Commit changes.
5. Mo Settings > Pages.
6. Build and deployment: Deploy from a branch.
7. Branch: main; folder: /(root); bam Save.
8. Doi GitHub Pages xuat ban. Link thuong co dang:
   https://nguyenthiminhong1107.github.io/kho-tro-choi-tom-jerry/

BUOC D - KIEM TRA
1. Mo link GitHub Pages. Hoc sinh co the xem game da xuat ban va gui ket qua.
2. Bam Dang nhap giao vien, dang nhap bang email va mat khau da tao trong Firebase Authentication.
3. Giao vien moi co the mo khu vuc tao/quan ly/Canva/thong ke.
4. Neu dang nhap bao sai email/mat khau, kiem tra Email/Password da Enable va tai khoan da duoc tao.
5. Neu khong doc/ghi duoc du lieu, kiem tra Firestore da tao va Rules da Publish.

BAO MAT VA LUU Y
- Firebase Web config (apiKey, authDomain, projectId, appId...) duoc dung trong trinh duyet va khong phai service-account private key.
- Tuyet doi khong dua file service account JSON, private key hay mat khau vao GitHub.
- Chi tai khoan da dang nhap bang email giao vien neu tren moi duoc Firestore Rules cap quyen.
- Hoc sinh khong can dang nhap; khong duoc doc collection attempts.
- GitHub repository dang Public nen ma nguon co the duoc xem. Khong dua du lieu ca nhan hoc sinh vao ma nguon.
- Day la goi tich hop co ban. Can kiem thu sau khi bat Auth, tao Firestore va publish Rules; khong xem viec tai file len GitHub la da hoan tat trien khai.
- Firebase Spark co han muc mien phi; vuot han muc co the lam dich vu bi gioi han.
